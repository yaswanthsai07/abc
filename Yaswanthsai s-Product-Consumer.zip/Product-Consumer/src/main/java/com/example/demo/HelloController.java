package com.example.demo;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;



@RestController
@RequestMapping("/helloc")
public class HelloController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@RequestMapping("/greet")
	public String getGreeting(){
		//eureka discovery instance 
		String message = restTemplate.getForObject("http://Product-Producer/hellop/greet", String.class);
		
		//without eureka
	//	String message = restTemplate.getForObject("http://localhost:8081/hellop/greet",String.class);	
		
		return "Product details recived FROM: Received: "+ message;
	}
	
	
}















//@RestController
//@RequestMapping("/helloc")
//public class HelloController {
//	@Autowired
//	private HelloService helloService;
//	
//	@Value("${eureka.instance.metadataMap.instanceId}")
//	private String instanceDetails;
//
//	@RequestMapping("/greet")
//	public String getGreeting(){
//		String message= helloService.getGreetings();
//		return "I am hello consumer service\n"+message+"\n FROM: "+instanceDetails;
//	}
//}
